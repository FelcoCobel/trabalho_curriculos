package com.example.trabalho_urriculos

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
